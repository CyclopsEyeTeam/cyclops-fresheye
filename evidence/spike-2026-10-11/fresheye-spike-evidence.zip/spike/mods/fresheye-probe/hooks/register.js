// CyclopsFreshEye V0 capability spike — probe mod. NOT the product.
// Scope: observe + gate context ONLY inside the FreshEye conversation.
// Never hooks tool.call / tool.check / permissions. Never touches settings.

const EVID = '/tmp/claude-0/-home-claude/cbbde8fa-7760-5346-8b22-6e2c8aa4a85a/scratchpad/spike/evidence'
let LOG = null // one file per module load: <EVID>/log-<pid-ish start ms>.jsonl
const AUTOPILOT_FLAG = EVID + '/AUTOPILOT'
const CANARY = /[A-Z]+-CANARY-\d+/g

const Q = 'Without using tools, list every token in your context that contains the substring CANARY, one per line, or reply NONE. ' +
  'Then on a final line write FIRST: followed by the first six words of the very first user message in this conversation.'

// ---- probe state (module variables live for the whole process; /clear and /resume do not reload the module)
let entries = []
let phase = 'origin'          // 'origin' | 'clearing' | 'fresh'
let originId = null
let freshId = null
let step = 'A'                // autopilot step
let leaveSnapshot = null      // origin transcript snapshot taken when leaving

const canaries = (s) => (typeof s === 'string' ? [...new Set(s.match(CANARY) || [])] : [])

async function sid($) { try { return await $.session.id() } catch { return null } }

async function log($, ev, data = {}) {
  const rec = { n: entries.length, t: await $.clock.now(), ev, sid: await sid($), phase, ...data }
  entries.push(rec)
  if (!LOG) LOG = `${EVID}/log-${rec.t}.jsonl`
  try { await $.fs.write(LOG, entries.map((r) => JSON.stringify(r)).join('\n') + '\n') } catch (err) { $.ui.log('probe log write failed: ' + err) }
}

async function isFreshNow($) {
  if (phase === 'clearing') return true
  if (phase !== 'fresh') return false
  const s = await sid($)
  return freshId === null || s === freshId
}

async function sha256(text) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text))
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('')
}

async function snapshot($) {
  const msgs = await $.session.messages()
  const texts = msgs.map((m) => m.role + ':' + (m.text || ''))
  const api = await $.session.messages({ as: 'api' })
  const firstUser = api.find((m) => m.role === 'user')
  const firstUserText = firstUser ? JSON.stringify(firstUser.content) : ''
  let transcript = null
  try {
    const cfg = await $.env.get('CLAUDE_CONFIG_DIR')
    const root = await $.session.root()
    const proj = root.replace(/[^A-Za-z0-9]/g, '-')
    const path = `${cfg}/projects/${proj}/${await sid($)}.jsonl`
    const body = await $.fs.read(path)
    transcript = { path, bytes: body.length, sha256: await sha256(body) }
  } catch (err) { transcript = { error: String(err) } }
  return {
    messageCount: msgs.length,
    messagesSha256: await sha256(texts.join('\u0000')),
    firstUserMessageCanaries: canaries(firstUserText),
    model: await $.session.model(),
    transcript,
  }
}

async function autopilot($) {
  try { return await $.fs.exists(AUTOPILOT_FLAG) } catch { return false }
}

// ---- the FreshEye behaviours under test -------------------------------------------------

async function openFreshEye($, prompt) {
  originId = await sid($)
  leaveSnapshot = await snapshot($)
  await log($, 'fresheye.open.begin', { originId, prompt, leaveSnapshot })
  phase = 'clearing'
  let clearResult
  try {
    clearResult = await $.command.run({ command: 'clear', args: 'fresheye-origin' })
  } catch (err) {
    phase = 'origin'
    await log($, 'CHECK1.clear.FAILED', { error: String(err) })
    return
  }
  freshId = await sid($)
  phase = 'fresh'
  $.ui.invalidate('prompt.section'); $.ui.invalidate('prompt.context'); $.ui.invalidate('prompt.attachment')
  await log($, 'CHECK1.clear.ok', { clearResult, originId, freshId, changedSession: freshId !== originId, model: await $.session.model() })
  $.ui.status('FreshEye · fresh context')
  const sub = await $.prompt.submit({ text: prompt, asUser: true })
  await log($, 'fresheye.prompt.submitted', { sub })
}

async function toggle($) {
  const here = await sid($)
  const target = here === freshId ? originId : (here === originId ? freshId : null)
  const targetLabel = target === originId ? 'original' : 'FreshEye'
  if (!target) { await log($, 'toggle.no-target', { here, originId, freshId }); return }
  let answer
  if (await autopilot($)) {
    answer = 'Switch (autopilot test harness substitute for $.ui.ask)'
    await log($, 'toggle.ask.autopilot-substitute', { question: `Switch to the ${targetLabel} conversation?` })
  } else {
    await log($, 'toggle.asking', { question: `Leave this conversation and switch to the ${targetLabel} one?`, here })
    try {
      answer = await $.ui.ask(`Leave this conversation and switch to the ${targetLabel} one?`, ['Switch', 'Stay here'])
    } catch (err) {
      await log($, 'toggle.ask.rejected-no-switch', { error: String(err) }) // fail closed
      return
    }
    if (!answer.startsWith('Switch')) { await log($, 'toggle.ask.declined', { answer }); return }
  }
  const before = await snapshot($)
  await log($, 'toggle.leaving', { from: here, to: target, before })
  if (here === originId) leaveSnapshot = before
  let res
  try {
    res = await $.command.run({ command: 'resume', args: target })
  } catch (err) {
    await log($, 'CHECK1.resume.FAILED', { error: String(err) })
    return
  }
  const now = await sid($)
  phase = now === freshId ? 'fresh' : 'origin'
  $.ui.invalidate('prompt.section'); $.ui.invalidate('prompt.context'); $.ui.invalidate('prompt.attachment')
  $.ui.status(phase === 'fresh' ? 'FreshEye · fresh context' : undefined)
  const after = await snapshot($)
  const rec = { res, now, landedOnTarget: now === target, after }
  if (now === originId && leaveSnapshot) {
    rec.CHECK5 = {
      messagesUnchanged: after.messagesSha256 === leaveSnapshot.messagesSha256 && after.messageCount === leaveSnapshot.messageCount,
      leave: { count: leaveSnapshot.messageCount, sha: leaveSnapshot.messagesSha256, transcript: leaveSnapshot.transcript },
      back: { count: after.messageCount, sha: after.messagesSha256, transcript: after.transcript },
    }
  }
  await log($, 'CHECK1.resume.ok', rec)
}

// ---- registration ------------------------------------------------------------------------

export const register = (on) => {
  on('session.start', async ($, e, next) => {
    await log($, 'session.start', { autopilot: await autopilot($), model: await $.session.model() })
    const r = await next(e)
    try {
      await $.command.register({ name: 'fresheye', description: 'FreshEye probe: /fresheye "prompt" opens a fresh context; bare toggles (ask first)', argumentHint: '["prompt"]' })
      await log($, 'command.registered')
    } catch (err) { await log($, 'command.register.FAILED', { error: String(err) }) }
    return r
  })

  on('command.run', { command: 'fresheye' }, async ($, e) => {
    const prompt = (e.args || '').trim().replace(/^"(.*)"$/s, '$1')
    await log($, 'fresheye.command', { args: e.args, origin: e.origin })
    // run outside this hook so $.command.run is not called inside a waited-on hook
    $.clock.after(50, () => (prompt ? openFreshEye($, prompt) : toggle($)).catch((err) => log($, 'fresheye.ERROR', { error: String(err) })))
    return { text: prompt ? 'FreshEye: opening a fresh context…' : 'FreshEye: switch requested (asks first)…' }
  })

  on('session.end', async ($, e, next) => {
    entries.push({ n: entries.length, ev: 'session.end', reason: e.reason, endingSession: e.sessionId, phase })
    return next(e)
  })

  // CHECK2/3: context blocks of a conversation's first message (CLAUDE.md lives here)
  on('prompt.context', async ($, e, next) => {
    const r = await next(e)
    const fresh = await isFreshNow($)
    const blocks = r.blocks.map((b) => ({ name: b.name, len: b.text.length, canaries: canaries(b.text) }))
    const files = (r.instructionFiles || e.instructionFiles || []).map((f) => f.path || f)
    if (fresh) {
      const kept = r.blocks.filter((b) => b.name !== 'claudeMd')
      await log($, 'CHECK2.prompt.context', { fresh, action: 'dropped claudeMd', blocks, files })
      return { blocks: kept, instructionFiles: [] }
    }
    await log($, 'CHECK2.prompt.context', { fresh, action: 'pass', blocks, files })
    return r
  })

  // CHECK3: system-prompt sections (auto memory is the `memory` section)
  on('prompt.section', async ($, e, next) => {
    const r = await next(e)
    const fresh = await isFreshNow($)
    const c = canaries(r && r.text)
    if (fresh && e.name === 'memory') {
      await log($, 'CHECK3.prompt.section', { name: e.name, fresh, action: 'dropped', len: (r.text || '').length, canaries: c })
      return { text: null }
    }
    if (c.length || e.name === 'memory') await log($, 'CHECK3.prompt.section', { name: e.name, fresh, action: 'pass', len: (r && r.text || '').length, canaries: c })
    return r
  })

  // CHECK4: injected messages, incl. settings-hook additionalContext (Remember-style)
  on('prompt.attachment', async ($, e, next) => {
    const r = await next(e)
    const fresh = await isFreshNow($)
    const c = canaries(r && r.text)
    const fromHook = e.origin && e.origin.kind === 'hook'
    // instruction files (CLAUDE.md + auto-memory index) are also announced as an engine `instructions` attachment
    const instructionFiles = e.origin && e.origin.kind === 'engine' && /instruction|memory/i.test(String(e.type))
    if (fresh && (fromHook || instructionFiles)) {
      await log($, 'CHECK4.prompt.attachment', { type: e.type, origin: e.origin, fresh, action: 'dropped', canaries: c })
      return { text: null }
    }
    await log($, 'CHECK4.prompt.attachment', { type: e.type, origin: e.origin, fresh, action: 'pass', canaries: c })
    return r
  })

  // observe only: do the settings hooks themselves still run?
  on('classic.SessionStart', async ($, e, next) => { await log($, 'classic.SessionStart', { source: e.source }); return next(e) })
  on('classic.UserPromptSubmit', async ($, e, next) => { await log($, 'classic.UserPromptSubmit', {}); return next(e) })

  // evidence + autopilot driver
  on('turn.complete', async ($, e, next) => {
    const r = await next(e)
    if (e.agentId !== undefined) return r
    const msgs = await $.session.messages()
    const last = msgs.at(-1)
    const here = await sid($)
    const where = here === freshId ? 'fresh' : (here === originId || originId === null ? 'origin' : 'other')
    await log($, 'answer', { where, step, answer: last && last.text, canariesSeen: canaries(last && last.text), snapshot: await snapshot($) })
    if (!(await autopilot($))) {
      // ASKTEST: exercise the real confirm-first path once, from the FreshEye conversation; nobody answers.
      if (where === 'fresh' && step === 'A' && (await $.fs.exists(EVID + '/ASKTEST').catch(() => false))) {
        step = 'ASKED'
        $.clock.after(300, () => toggle($).catch((err) => log($, 'asktest.ERROR', { error: String(err) })))
        $.clock.after(30000, async () => log($, 'asktest.after30s', { stillHere: await sid($), freshId }))
      }
      return r
    }
    const go = (fn) => $.clock.after(300, () => fn().catch((err) => log($, 'autopilot.ERROR', { step, error: String(err) })))
    // A mod's own $.command.run skips the mod's own hooks, so autopilot calls the same functions the
    // /fresheye command.run hook calls. The typed-command path is exercised separately (SDK input run).
    if (step === 'A') { step = 'B'; go(() => openFreshEye($, Q)) }
    else if (step === 'B') { step = 'C'; go(async () => { await toggle($); await $.prompt.submit({ text: Q, asUser: true }) }) }
    else if (step === 'C') { step = 'D'; go(async () => { await toggle($); await $.prompt.submit({ text: Q, asUser: true }) }) }
    else if (step === 'D') { step = 'DONE'; go(async () => { await log($, 'autopilot.DONE'); await $.fs.write(EVID + '/DONE', 'done\n') }) }
    return r
  })
}
