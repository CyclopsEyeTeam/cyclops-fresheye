# Scratch project (FreshEye spike)

Project codename: ZEBRA-CANARY-41. (This line is the CLAUDE.md canary.)
