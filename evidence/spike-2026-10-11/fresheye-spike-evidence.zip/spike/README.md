# CyclopsFreshEye V0 — mod capability spike (evidence bundle)

Claude Code 2.1.296 · model claude-haiku-5-5 · 2026-10-11 · disposable sandbox only.

- `mods/fresheye-probe/` — the probe mod (loaded with `--plugin-dir` only). Hooks: see `evidence/probe-validate.txt`.
  It never hooks `tool.call` / `tool.check`, and writes nothing but its own log.
- `repo/` — scratch git repo: `CLAUDE.md` canary ZEBRA-CANARY-41, project `.claude/settings.json` with
  Remember-style SessionStart (WOMBAT-CANARY-93) and UserPromptSubmit (OTTER-CANARY-58) hooks.
- `cfg/` — isolated CLAUDE_CONFIG_DIR; auto memory `projects/*/memory/MEMORY.md` canary MAGENTA-CANARY-77.
- `cenv.sh` — clean env: own HOME + CLAUDE_CONFIG_DIR, proxy/CA only.
- `run.sh <autopilot|ask|ask-notool> <name>` — real TTY via `script`; stdin held open, no input ever written;
  the only external prompt is the documented `claude "<initial prompt>"` argument.
- `verify.py <run-dir>` — re-derives every claim from the run's probe log + copied transcripts → `VERIFY.json`.

Runs
- `evidence/A-roundtrip`  origin → /fresheye → back to origin → back to FreshEye (autopilot; ask substituted, logged as such)
- `evidence/B-typed-confirm`  person-typed `/fresheye "<Q>"` (origin `composer`); then the real ask shown and left unanswered 30 s
- `evidence/C-confirm-unavailable`  same, with AskUserQuestion removed (`--tools ''`): ask rejects → no switch
- `evidence/_discarded/`  first attempts; run2–4 logs were overwritten by a hot reload of a still-running probe. Not used as evidence.

Reproduce: `./run.sh autopilot A2 && python3 verify.py evidence/A2`
