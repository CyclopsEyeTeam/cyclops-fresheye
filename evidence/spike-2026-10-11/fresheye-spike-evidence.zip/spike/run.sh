#!/bin/bash
# FreshEye spike harness. Usage: run.sh <autopilot|ask|ask-notool> <run-name>
#  - Real interactive TTY via `script`; stdin is held open and NO input is ever written (no keystrokes).
#  - The only prompt from outside is the documented `claude "<initial prompt>"` argument.
#  - Isolated CLAUDE_CONFIG_DIR + HOME (cenv.sh); the probe is loaded with --plugin-dir.
#  - Evidence = the probe's own JSONL log + the session transcripts on disk; the pty capture is kept only for debugging.
set -u
S=/tmp/claude-0/-home-claude/cbbde8fa-7760-5346-8b22-6e2c8aa4a85a/scratchpad/spike
MODE=$1; RUN=$2; OUT=$S/evidence/$RUN; mkdir -p $OUT
Q='Without using tools, list every token in your context that contains the substring CANARY, one per line, or reply NONE. Then on a final line write FIRST: followed by the first six words of the very first user message in this conversation.'
rm -f $S/evidence/AUTOPILOT $S/evidence/ASKTEST $S/evidence/DONE $S/evidence/log-*.jsonl
case $MODE in
  autopilot)  touch $S/evidence/AUTOPILOT; TOOLS="''";              INIT="\"$Q\"";;
  ask)        touch $S/evidence/ASKTEST;   TOOLS="AskUserQuestion"; INIT="'/fresheye \"$Q\"'";;
  ask-notool) touch $S/evidence/ASKTEST;   TOOLS="''";              INIT="'/fresheye \"$Q\"'";;
esac
cd $S/repo
( sleep 400 | timeout 300 script -q -f -c "$S/cenv.sh claude --model haiku --tools $TOOLS --plugin-dir $S/mods/fresheye-probe $INIT" $OUT/pty.raw > /dev/null 2>&1 ) > /dev/null 2>&1 < /dev/null &
for i in $(seq 1 50); do
  sleep 5
  [ -f $S/evidence/DONE ] && break
  grep -qs asktest.after30s $S/evidence/log-*.jsonl && break
done
sleep 3
ps -eo pid,args | grep -E "[p]lugin-dir $S/mods/fresheye-probe" | awk '{print $1}' | xargs -r kill 2>/dev/null
ps -eo pid,args | grep -E "^ *[0-9]+ sleep 400$" | awk '{print $1}' | xargs -r kill 2>/dev/null
sleep 2
mv $S/evidence/log-*.jsonl $OUT/ 2>/dev/null
cp -r $S/cfg/projects $OUT/transcripts
rm -f $S/evidence/AUTOPILOT $S/evidence/ASKTEST $S/evidence/DONE
echo "$RUN finished: $(ls $OUT)"
