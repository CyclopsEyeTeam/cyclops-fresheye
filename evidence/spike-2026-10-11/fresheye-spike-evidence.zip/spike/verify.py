# Usage: verify.py <run-dir>   — re-derives every claim from the run's own probe log + transcript copies.
import json, hashlib, os, sys, glob
S = "/tmp/claude-0/-home-claude/cbbde8fa-7760-5346-8b22-6e2c8aa4a85a/scratchpad/spike"
run = sys.argv[1]
log = [json.loads(l) for l in open(glob.glob(f"{run}/log-*.jsonl")[0])]
ev = lambda name: [r for r in log if r["ev"] == name]
out = {"run": os.path.basename(run)}
out["answers"] = [{"where": r["where"], "session": r["sid"][:8], "canariesSeen": r["canariesSeen"], "messageCount": r["snapshot"]["messageCount"], "model": r["snapshot"]["model"]} for r in ev("answer")]
out["check1_clear"] = [{"ok": True, "origin": r["originId"][:8], "fresh": r["freshId"][:8], "sameModel": r["model"]} for r in ev("CHECK1.clear.ok")] + [{"ok": False, "error": r["error"]} for r in ev("CHECK1.clear.FAILED")]
out["check1_resume"] = [{"landedOnTarget": r["landedOnTarget"], "now": r["now"][:8]} for r in ev("CHECK1.resume.ok")] + [{"ok": False, "error": r["error"]} for r in ev("CHECK1.resume.FAILED")]
out["check2_context_fired_after_clear"] = any(r["fresh"] for r in ev("CHECK2.prompt.context"))
out["drops_by_session"] = {}
for r in log:
    if r.get("action", "").startswith("dropped"):
        out["drops_by_session"].setdefault(r["sid"][:8], set()).add(r["ev"] + ":" + str(r.get("type") or r.get("name") or "claudeMd"))
out["drops_by_session"] = {k: sorted(v) for k, v in out["drops_by_session"].items()}
out["settings_hooks_still_ran"] = sorted({(r["ev"], r.get("source", "")) for r in log if r["ev"].startswith("classic.")})
c5 = [r["CHECK5"] for r in ev("CHECK1.resume.ok") if "CHECK5" in r]
if c5:
    c5 = c5[0]; lt = c5["leave"]["transcript"]
    copy = os.path.join(run, "transcripts", os.path.relpath(lt["path"], f"{S}/cfg/projects"))
    body = open(copy, encoding="utf-8").read()
    out["check5"] = {
        "messagesUnchanged(count+sha)": c5["messagesUnchanged"],
        "originTranscriptAtLeaveIsExactPrefixOfFinal": hashlib.sha256(body[:lt["bytes"]].encode()).hexdigest() == lt["sha256"],
        "originTranscriptBytes(leave,final)": [lt["bytes"], len(body)],
    }
asks = [r["ev"] for r in log if r["ev"].startswith("toggle.") or r["ev"].startswith("asktest")]
if asks: out["confirm_path"] = asks + [r.get("error", "") for r in ev("toggle.ask.rejected-no-switch")]
after = ev("asktest.after30s")
if after: out["noSwitchWithoutConfirm"] = after[0]["stillHere"] == after[0]["freshId"]
out["transcripts_on_disk"] = sorted(os.path.basename(p) for p in glob.glob(f"{run}/transcripts/*/*.jsonl"))
print(json.dumps(out, indent=1))
